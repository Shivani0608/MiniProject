create trigger on_insert
  after INSERT
  on teacher_info
  for each row
  begin
insert into teacher_login values(new.mis_id,new.set_password);
end;

